/*Agra Nibrasul Al Fauzan /123210148/Plug F
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tugaspbo;

import java.util.Scanner;
import tugaspbo.ruang.Balok;
import tugaspbo.ruang.Tabung;

/**
 *
 * @author User
 */
public class TugasPbo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int menu;
        boolean repeat = true;
        
        while(repeat) {
            System.out.println("=== MENU ===");
            System.out.println("1. Hitung Balok");
            System.out.println("2. Hitung Tabung");
            System.out.println("3. Keluar");
            System.out.print("Pilih menu: ");
            menu = input.nextInt();
            
            switch(menu) {
                case 1 :
                    hitungBalok();
                    break;
                case 2 :
                    hitungTabung();
                    break;
                case 3 : {
                    System.out.println("Terima kasih!");
                    repeat = false;
                }
                default : System.out.println("Menu tidak tersedia.");
            }
            
            if(repeat) {
                System.out.println("\nTekan enter untuk kembali ke menu...");
                input.nextLine(); // Membuang newline di buffer
                input.nextLine(); // Menunggu input enter
            }
        }
    }
    
    public static void hitungBalok() {
        Scanner input = new Scanner(System.in);
        int panjang, lebar, tinggi;
        
        System.out.println("\n== Hitung Balok ==");
        System.out.print("Masukkan panjang: ");
        panjang = input.nextInt();
        System.out.print("Masukkan lebar: ");
        lebar = input.nextInt();
        System.out.print("Masukkan tinggi: ");
        tinggi = input.nextInt();
        
        
        Balok balok = new Balok(panjang, lebar, tinggi);
        System.out.println("Luas permukaan balok: " + balok.hitungLuasPermukaan());
        System.out.println("Keliling persegi panjang: " + balok.hitungKeliling());
        System.out.println("Luas persegi panjang: " + balok.hitungLuas());
        System.out.println("Volume balok: " + balok.hitungVolume());
    }
    
    public static void hitungTabung() {
        Scanner input = new Scanner(System.in);
        double jariJari, tinggi;
        
        System.out.println("\n== Hitung Tabung ==");
        System.out.print("Masukkan jari-jari: ");
        jariJari = input.nextDouble();
        System.out.print("Masukkan tinggi: ");
        tinggi = input.nextDouble();
        
        Tabung tabung = new Tabung(jariJari, tinggi);
        System.out.println("Luas permukaan tabung: " + tabung.hitungLuasPermukaan());
        System.out.println("Keliling lingkaran: " + tabung.hitungKeliling());
        System.out.println("Luas lingkaran: " + tabung.hitungLuas());
        System.out.println("Volume tabung: " + tabung.hitungVolume());
    }
    }

