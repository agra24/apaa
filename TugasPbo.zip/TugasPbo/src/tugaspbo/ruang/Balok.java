/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugaspbo.ruang;

import tugaspbo.bidang.PersegiPanjang;

/**
 *
 * @author User
 */
public class Balok extends PersegiPanjang implements MenghitungRuang {
    private int  tinggi;

    public Balok(int tinggi, int panjang, int lebar) {
        super(panjang, lebar);
        this.tinggi = tinggi;
    }

   
    
    @Override
    public double hitungVolume() {
        return hitungLuas() * tinggi;
    }

    @Override
    public double hitungLuasPermukaan() {
        return 2 * (hitungLuas() + (panjang * tinggi) + (lebar * tinggi) + (panjang * lebar));
    }
}


