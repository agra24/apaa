/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugaspbo.bidang;

/**
 *
 * @author User
 */
public class PersegiPanjang implements MenghitungBidang {
    public int panjang;
    public int lebar;

    public PersegiPanjang(int panjang, int lebar) {
        this.panjang = panjang;
        this.lebar = lebar;
    }

    @Override
    public double hitungLuas() {
        return panjang * lebar;
    }

    /**
     *
     * @return
     */
    @Override
    public double hitungKeliling() {
        return 2 * (panjang + lebar);
    }
}


